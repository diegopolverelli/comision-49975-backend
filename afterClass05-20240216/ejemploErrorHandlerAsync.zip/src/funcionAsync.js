import { CustomError, ERROR_STATUS_CODE } from "./errores.js"

export const mayuscula=async(texto="")=>{

    // en las funciones "internas", donde no llega a response, directamente lanzo el error
    // lanzo el CustomError, con la info pertinente si es para una validación (donde yo sé lo que falla...)
    // o bien con una descripción genérica (usando CustomError o simplemente Error) si estoy en un catch (try/catch)    
    // ver ejemplo en función validar, al pie de este script

    let cantidadLetras=await cuentaLetras(texto)
    console.log(`La palabra ${texto} tiene ${cantidadLetras} letras...!!!`)

    if(typeof texto!=="string"){
        // throw new Error()
        throw new CustomError("Tipo de datos incorrecto", ERROR_STATUS_CODE.ARGUMENTOS_INVALIDOS, "Error, función mayuscula", `Tipo de datos incorrecto: se esperaba string, se recibió ${typeof texto}`)
    }
    return texto.toUpperCase()

}

const cuentaLetras=async(texto="")=>{

    let esValida=await validar(texto)
    if(esValida){
        console.log(`La palabra ${texto} es válida...!!!`)
    }

    if(typeof texto!=="string"){
        // throw new Error()
        throw new CustomError("Tipo de datos incorrecto", ERROR_STATUS_CODE.ARGUMENTOS_INVALIDOS, "Error, función cuentaLetras", `Tipo de datos incorrecto: se esperaba string, se recibió ${typeof texto}`)
    }
    return texto.length
}

const validar=async(texto)=>{

    try {
        // codigo que puede fallar
        
        console.prueba() // no existe, deberia disparar un error
                         // Si comento el console.prueba, en endpoint /asyncOK se ejecuta de manera correcta (sin errores)

    } catch (error) {
        // para los try catch internos, en el catch, hago un throw new CustomError
        // Sería un error desconocido, ya que justamente esto captura errores inesperados
        throw new CustomError("Error indeterminado (ver detalle)", ERROR_STATUS_CODE.DESCONOCIDO, "Error, función validar", error.message)
    }

    // lanzaError()    // funcion sincrona que genera Error
    // lanzaCustomError()    // funcion sincrona que genera CustomError
    
    // realizar alguna validación...
    if(typeof texto!=="string"){
        // throw new Error()

        // ante una validación que falla, directamente hago el throw new CustomError
        // indicando el error puntual, con el detalle pertinente
        throw new CustomError("Tipo de datos incorrecto", ERROR_STATUS_CODE.ARGUMENTOS_INVALIDOS, "Error, función validar", `Tipo de datos incorrecto: se esperaba string, se recibió ${typeof texto}`)
    }
    


    

    return true
}

const lanzaError=()=>{
    throw new Error("holis...??? Error... :(")
}

const lanzaCustomError=()=>{
    throw new CustomError("Error forzado", ERROR_STATUS_CODE.BAD_REQUEST, "Error forzado en funcion lanzaCustomError", "Error forzado en función sincrona lanzaCustomError()...")
}