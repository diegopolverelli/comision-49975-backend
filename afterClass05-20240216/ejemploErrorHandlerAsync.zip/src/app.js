// https://expressjs.com/en/guide/error-handling.html

import express from 'express';
import { CustomError, ERROR_STATUS_CODE, errorHandler} from './errores.js';
import { mayuscula } from './funcionAsync.js';
import fs from 'fs'

const PORT=3000;

const app=express();

app.use(express.json());
app.use(express.urlencoded({extended:true}));

app.get('/',async(req,res,next)=>{ // para generar un error, ingresar un query param error=1     http://localhost:3000?error=1
                                   // Al ser una función async, en el catch debo hacer next(error); y en la firma de 
                                   // la función debo agregar next, como si fuese un middleware:    app.get('/',async(req,res,next)
    try {
        let {error}=req.query
        if(error){
            throw new CustomError("Error de prueba - name", ERROR_STATUS_CODE.BAD_REQUEST, "Error de prueba - message", "Error de prueba -  descripción detallada..." )
        }
    
        res.setHeader('Content-Type','text/plain');
        res.status(200).send('OK');
        
    } catch (error) {
        next(error)   // al ser async function, tengo que enviar el error que capturo
                      // con el catch, por medio de un next(error)
    }
})

app.get("/sync", (req,res)=>{  // al ser sincrona, el error es capturado directamente por el middleware

    throw new CustomError("Error prueba - name", ERROR_STATUS_CODE.BAD_REQUEST, "Error prueba - mensaje", "Error prueba, descripcion detallada...")

    res.send("Ruta /sync...!!!")

})

app.get("/archivo", (req,res, next)=>{  // intento leer un archivo inexistente con fs.writeFile (método asincrono que usa callbaks)
                                        // Al provenir el error desde una función async (fs.readFile()), también tengo que pasar el error
                                        // al middleware con un next(error); 
                                        // En este caso aprovecho y utilizo mi error personalizado haciendo next(new CustomError())
    fs.readFile("./archivo-que-no-existe.txt",{encoding:"utf-8"},(error, datoLeido)=>{
        if(error){
            // next(error)
            next(new CustomError("Error al leer archivo", 404, error.name, error.message ))
        }

        res.send(datoLeido)
    })

})


// este endpoint recibe un params que puede ser:
//      - un texto cualquiera (menos "error"), en cuyo caso se mostrará el texto ingresado, transformado a mayuscula
//      - la palabra "error", en cuyo caso se simulará un error inesperado (ver función validar en script funcionAsync.js)
//      - un numero cualquiera (por ejemplo 200), en cuyo caso se mostrará un error customizado, por haber ingresado
//        un dato en formato inadecuado (CustomError por validación)
app.get("/mayuscula/:texto",async(req, res, next)=>{  // al ser async, tengo que agregar en la firma un next,
                                                      // y usarlo para pasar el error al middleware en el catch

    try {
        let resultado
        if(isNaN(Number(req.params.texto))){
            resultado=await mayuscula(req.params.texto)
        }else{
            resultado=await mayuscula(Number())
        }
        res.send(resultado)
        
    } catch (error) {
        next(error)    // si capturo un error con el catch, lo retransmito al middleware vía next(error)
                       // Esto es por ser una función asincrona
    }
})


app.use(errorHandler)  // middleware de errores 

const server=app.listen(PORT,()=>{
    console.log(`Server escuchando en puerto ${PORT}`);
});
