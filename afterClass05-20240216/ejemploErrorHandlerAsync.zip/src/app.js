import express from 'express';
import { CustomError, ERROR_STATUS_CODE, errorHandler, trataError } from './errores.js';
import { mayuscula } from './funcionAsync.js';

const PORT=3000;

const app=express();

app.use(express.json());
app.use(express.urlencoded({extended:true}));

app.get('/',async(req,res)=>{ // ingresar un query param error=1     http://localhost:3000?error=1
                              // al ser async, uso tratarError en el catch (es la función que usa también el middleware internamente)
    try {
        let {error}=req.query
        if(error){
            throw new CustomError("Error de prueba - name", ERROR_STATUS_CODE.BAD_REQUEST, "Error de prueba - message", "Error de prueba -  descripción detallada..." )
        }
    
        res.setHeader('Content-Type','text/plain');
        res.status(200).send('OK');
        
    } catch (error) {
        trataError(error, res)
    }
})

app.get("/sync", (req,res)=>{  // al ser sincrona, el error es capturado por el middleware

    throw new CustomError("Error prueba - name", ERROR_STATUS_CODE.BAD_REQUEST, "Error prueba - mensaje", "Error prueba, descripcion detallada...")

    res.send("Ruta /sync...!!!")

})

app.get("/async",async(req, res)=>{  // al ser async, en el catch uso tratarError (que es también lo que usa el middleware)

    try {
        let resultado=await mayuscula(1000)
        res.send(resultado)
        
    } catch (error) {
        trataError(error, res)
    }
})

app.get("/asyncOK",async(req, res)=>{  // al ser async, en el catch uso tratarError (que es también lo que usa el middleware)

    try {
        let resultado=await mayuscula("CoderHouse")
        res.send(resultado)
        
    } catch (error) {
        trataError(error, res)
    }
})


app.use(errorHandler)  // middleware de errores (internamente utiliza tratarError - ver errores.js)

const server=app.listen(PORT,()=>{
    console.log(`Server escuchando en puerto ${PORT}`);
});
