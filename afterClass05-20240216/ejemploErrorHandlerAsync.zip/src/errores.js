export class CustomError extends Error {
    constructor(nombre, statusCode, mensaje, descripcion = "") {
        super(mensaje)
        this.codigo = statusCode
        this.descripcion = descripcion
        this.name = nombre
    }
}


export const ERROR_STATUS_CODE = {
    BAD_REQUEST: 400,
    TIPO_DE_DATOS: 400,
    ARGUMENTOS_INVALIDOS: 400,
    AUTENTICACION: 401,
    NOT_FOUND: 404,
    AUTORIZACION: 403,
    DESCONOCIDO: 500
}


export const errorHandler = (error, req, res, next) => {
    if (error) {
        if (error instanceof CustomError) {
            console.log(`Error (${error.codigo}) - ${error.name.trim()}:  ${error.message.trim()} - Detalle: ${error.descripcion}`)
            res.setHeader('Content-Type', 'application/json');
            return res.status(error.codigo).json({
                error: `${error.message}`,
                detalle: `Error (${error.codigo}) - ${error.name.trim()}:  ${error.descripcion}`.toString()
            })
        } else {
            res.setHeader('Content-Type', 'application/json');
            return res.status(500).json({ error: `Error inesperado en el servidor - Intente más tarde, o contacte a su administrador` })
        }

    }

    next()
}

